import React from 'react';
import { History } from '../components/History/History';
function ResultPage(props) {
    return (
        <div>
            <History />

        </div>
    );
}

export default ResultPage;