import React from 'react';
import CreateAccount from '../components/User/CreateAcc';
function CreateAccountPage(props) {
    return (
        <div>
            <CreateAccount />
        </div>
    );
}

export default CreateAccountPage;