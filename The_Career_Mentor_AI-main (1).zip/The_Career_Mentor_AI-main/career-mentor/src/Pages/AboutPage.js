import React from 'react';
import TwoColumnSection from '../components/Navbar/TwoColumnSection';
function AboutPage() {
    return (
        <div>
            <TwoColumnSection />
        </div>
    );
}

export default AboutPage;