import React from 'react';
import Login from '../components/User/Login';
function LoginPage() {
    return (
        <div>
            <Login />
        </div>
    );
}

export default LoginPage;